(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[10],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/currentComponents/ScannerCode.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/currentComponents/ScannerCode.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_barcode_reader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-barcode-reader */ "./node_modules/vue-barcode-reader/src/index.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  name: "ScannerCode",
  components: {
    StreamBarcodeReader: vue_barcode_reader__WEBPACK_IMPORTED_MODULE_0__["StreamBarcodeReader"]
  },
  data: function data() {
    return {
      loading: true,
      text: "",
      id: null
    };
  },
  beforeMount: function beforeMount() {
    this.loading = true;
  },
  props: {
    msg: String,
    openScann: {
      type: Boolean,
      "default": false
    },
    isModal: {
      type: Boolean,
      "default": false
    }
  },
  // http://sccrm.mx/c.php?t=DbyMvZc91nqhFNKLqA3wwphBk&a=42403
  watch: {
    openScann: function openScann(value) {
      if (value) {
        this.showModal();
      } else {
        this.hideModal();
      }
    },
    text: function text(value) {
      if (value != '') {
        this.$emit('changeText', this.text);
      }
    }
  },
  methods: {
    onDecode: function onDecode(a, b, c) {
      var _this = this;
      console.log(a, b, c);
      this.text = a;
      if (this.id) clearTimeout(this.id);
      this.id = setTimeout(function () {
        if (_this.text === a) {
          _this.text = "";
        }
      }, 5000);
    },
    onLoaded: function onLoaded() {
      this.loading = false;
    },
    showModal: function showModal() {
      this.$refs['my-modal'].show();
    },
    hideModal: function hideModal() {
      this.$refs['my-modal'].hide();
    },
    toggleModal: function toggleModal() {
      // We pass the ID of the button that we want to return focus to
      // when the modal has hidden
      this.$refs['my-modal'].toggle('#toggle-btn');
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/horas/Horas.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/horas/Horas.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Users_plomo_Documents_MAMP_vol_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _currentComponents_FormFactory_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @currentComponents/FormFactory.vue */ "./resources/js/src/views/currentComponents/FormFactory.vue");
/* harmony import */ var _currentComponents_VistaUno_vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @currentComponents/VistaUno.vue */ "./resources/js/src/views/currentComponents/VistaUno.vue");
/* harmony import */ var _apis_usePeticiones__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/apis/usePeticiones */ "./resources/js/src/apis/usePeticiones.js");
/* harmony import */ var _helpers_customHelpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @helpers/customHelpers */ "./resources/js/src/helpers/customHelpers.js");
/* harmony import */ var _views_voluntarios_formVoluntario_vue__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @/views/voluntarios/formVoluntario.vue */ "./resources/js/src/views/voluntarios/formVoluntario.vue");
/* harmony import */ var _views_horas_formHoras_vue__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/views/horas/formHoras.vue */ "./resources/js/src/views/horas/formHoras.vue");




//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//







/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    FormFactory: _currentComponents_FormFactory_vue__WEBPACK_IMPORTED_MODULE_4__["default"],
    VistaUno: _currentComponents_VistaUno_vue__WEBPACK_IMPORTED_MODULE_5__["default"],
    formHoras: _views_horas_formHoras_vue__WEBPACK_IMPORTED_MODULE_9__["default"]
  },
  data: function data() {
    return {
      accion: 1,
      activeRow: null,
      schemaMain: null,
      showForm: false,
      data: [],
      formSchema: [{
        classContainer: 'col-lg-4 col-md-6 col-12',
        type: 'input-select',
        name: 'persona',
        value: 'persona',
        label: 'Persona'
      }, {
        classContainer: 'col-lg-4 col-md-6 col-12',
        type: 'input-select',
        name: 'tipo de usuario',
        value: 'tipoUsuario',
        label: 'Tipo de usuario',
        rules: 'required',
        catalogo: 'tiposUsuario'
      }, {
        classContainer: 'col-lg-4 col-md-6 col-12',
        type: 'text',
        name: 'usuario',
        value: 'usuario',
        label: 'Usuario',
        placeholder: 'Introduce un usuario',
        rules: 'required',
        prefixIcon: 'UserIcon'
      }, {
        classContainer: 'col-lg-4 col-md-6 col-12',
        type: 'password',
        name: 'contraseña',
        value: 'contraseña',
        label: 'Contraseña',
        placeholder: 'Introduce una contraseña',
        rules: 'required',
        // rules       : 'required|min:6|max:12',
        prefixIcon: 'LockIcon'
      }, {
        classContainer: 'col-lg-4 col-md-6 col-12',
        type: 'email',
        name: 'correo',
        value: 'email',
        prefixIcon: 'MailIcon',
        rules: 'required|email',
        label: 'Correo electronico',
        placeholder: 'Introduce un correo electronico'
      }, {
        classContainer: 'col-lg-4 col-md-6 col-12',
        type: 'input-phone',
        name: 'telefono',
        value: 'telefono',
        label: 'Telefono',
        rules: 'required',
        placeholder: 'Introduce un telefono celular'
      }, {
        classContainer: ' col-lg-4 col-md-4 col-sm-12 col-12',
        type: 'input-switch',
        name: 'accesoMovil',
        value: 'accesoMovil',
        label: 'Acceso a la plataforma movil',
        rules: 'required',
        labels: {
          'on': "Si",
          'off': "No"
        }
      }, {
        classContainer: ' col-lg-4 col-md-4 col-sm-12 col-12',
        type: 'input-switch',
        name: 'accesoWeb',
        value: 'accesoWeb',
        label: 'Acceso a la plataforma web',
        rules: 'required',
        labels: {
          'on': "Si",
          'off': "No"
        }
      }, {
        classContainer: ' col-lg-4 col-md-4 col-sm-12 col-12',
        type: 'input-switch',
        name: 'bloqueado',
        value: 'bloqueado',
        label: '¿Esta bloqueado?',
        rules: 'required',
        labels: {
          'on': "Si",
          'off': "No"
        }
      }],
      columnas: [{
        type: 'text',
        key: 'numeroAsociado',
        label: 'Numero de asociado',
        sortable: true
      }, {
        type: 'text',
        key: 'voluntario',
        label: 'Voluntario',
        sortable: true
      }, {
        type: 'text',
        key: 'actividad',
        label: 'Actividad',
        sortable: true
      }, {
        type: 'fechaTime',
        key: 'fecha',
        label: 'Fecha',
        sortable: true
      }, {
        type: 'fechaTime',
        key: 'horaInicio',
        label: 'Hora de inicio',
        sortable: true
      }, {
        type: 'fechaTime',
        key: 'horaFin',
        label: 'Hora de fin',
        sortable: true
      }, {
        type: 'text',
        key: 'numeroHoras',
        label: 'Horas registradas',
        sortable: true
      }]
    };
  },
  mixins: [_helpers_customHelpers__WEBPACK_IMPORTED_MODULE_7__["default"]],
  beforeMount: function beforeMount() {
    this.inicializar();
  },
  methods: {
    inicializar: function inicializar() {
      this.schemaMain = this.copyObject(this.formSchema);
      this.reload();
    },
    reload: function reload() {
      var _this = this;
      _apis_usePeticiones__WEBPACK_IMPORTED_MODULE_6__["default"].getHorasVoluntarias({}).then(function (response) {
        var data = response.data.data;
        data.forEach(function (element, index) {
          if (element['voluntario'] != null) {
            data[index]['voluntario'] = element.voluntario.nombre + ' ' + element.voluntario.primerApellido + ' ' + element.voluntario.segundoApellido;
            data[index]['numeroAsociado'] = element.voluntario.numeroAsociado;
          }
        });
        _this.data = data;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    resetForm: function resetForm() {
      this.accion = 1;
      this.showForm = false;
      this.activeRow = null;
      this.reload();
    },
    save: function save(data) {
      var payload = this.copyObject(data);
      if (this.accion == 2) {
        payload.id = this.activeRow.id;
      }
      payload.accion = this.accion;
      this.peticionAdministrar(payload);
    },
    peticionAdministrar: function peticionAdministrar(payload) {
      var _this2 = this;
      this.loading();
      _apis_usePeticiones__WEBPACK_IMPORTED_MODULE_6__["default"].administrarVoluntarios({
        'payload': payload
      }).then(function (response) {
        _this2.loading(false);
        _this2.messageSweet({
          message: response.data.message,
          icon: response.data.result ? 'success' : 'error'
        });
        _this2.resetForm();
      })["catch"](function (error) {
        _this2.loading(false);
        console.log(error);
      });
    },
    nuevoRegistro: function nuevoRegistro() {
      var _this3 = this;
      this.schemaMain = this.copyObject(this.formSchema);
      this.activeRow = {};
      setTimeout(function () {
        _this3.showForm = true;
      }, 10);
    },
    editar: function editar(data) {
      this.accion = 2;
      var tmp = this.copyObject(data);
      if (typeof tmp.tipo_usuario != 'undefined') {
        tmp.tipoUsuario = {
          value: tmp.tipoUsuario_id,
          label: tmp.tipo_usuario.nombre
        };
      }
      tmp.accesoMovil = typeof tmp.accesoMovil == 'number' ? tmp.accesoMovil ? true : false : false;
      tmp.accesoWeb = typeof tmp.accesoWeb == 'number' ? tmp.accesoWeb ? true : false : false;
      tmp.bloqueado = typeof tmp.bloqueado == 'number' ? tmp.bloqueado ? true : false : false;
      this.activeRow = this.copyObject(tmp);
      var tmpSchema = this.copyObject(this.formSchema);
      tmpSchema.splice(3, 1);
      this.schemaMain = tmpSchema;
      this.showForm = true;
    },
    onEliminar: function onEliminar(data) {
      var _this4 = this;
      console.log('eliminar');
      this.messageConfirm({
        confirmFunction: function confirmFunction() {
          _this4.peticionAdministrar(Object(_Users_plomo_Documents_MAMP_vol_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])(Object(_Users_plomo_Documents_MAMP_vol_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, data), {}, {
            accion: 3
          }));
        }
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/horas/formHoras.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/horas/formHoras.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _views_horas_formPorGuardia_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/views/horas/formPorGuardia.vue */ "./resources/js/src/views/horas/formPorGuardia.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'formPorGuardia',
  components: {
    BCard: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCard"],
    BCardTitle: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardTitle"],
    BCardSubTitle: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardSubTitle"],
    BCardBody: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardBody"],
    BModal: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BModal"],
    BButton: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BButton"],
    FormPorGuardia: _views_horas_formPorGuardia_vue__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  mounted: function mounted() {},
  data: function data() {
    return {
      tipoRegistro: null
    };
  },
  props: {},
  watch: {},
  computed: {},
  created: function created() {},
  beforeMount: function beforeMount() {},
  methods: {}
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/horas/formPorGuardia.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/horas/formPorGuardia.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _apis_usePeticiones__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/apis/usePeticiones */ "./resources/js/src/apis/usePeticiones.js");
/* harmony import */ var _helpers_customHelpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @helpers/customHelpers */ "./resources/js/src/helpers/customHelpers.js");
/* harmony import */ var vue_onoff_toggle__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vue-onoff-toggle */ "./node_modules/vue-onoff-toggle/dist/vue-onoff-toggle.esm.js");
/* harmony import */ var _currentComponents_ScannerCode_vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @currentComponents/ScannerCode.vue */ "./resources/js/src/views/currentComponents/ScannerCode.vue");

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//






/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'formPorGuardia',
  components: {
    Scann: _currentComponents_ScannerCode_vue__WEBPACK_IMPORTED_MODULE_5__["default"],
    BCard: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCard"],
    BCardTitle: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCardTitle"],
    BCardSubTitle: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCardSubTitle"],
    BCardBody: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCardBody"],
    BModal: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BModal"],
    BFormCheckboxGroup: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BFormCheckboxGroup"],
    BFormCheckbox: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BFormCheckbox"],
    BButton: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BButton"],
    OnoffToggle: vue_onoff_toggle__WEBPACK_IMPORTED_MODULE_4__["default"]
  },
  mixins: [_helpers_customHelpers__WEBPACK_IMPORTED_MODULE_3__["default"]],
  data: function data() {
    return {
      userData: JSON.parse(localStorage.getItem('userData')),
      guardia: null,
      codigo: null,
      voluntarios: null,
      openScann: false,
      hadScann: false,
      checked: true
    };
  },
  props: {},
  watch: {},
  computed: {},
  beforeMount: function beforeMount() {
    this.init();
  },
  mounted: function mounted() {},
  created: function created() {},
  methods: {
    handleOpenScann: function handleOpenScann() {
      var _this = this;
      this.hadScann = true;
      setTimeout(function () {
        _this.openScann = true;
      }, 3);
    },
    handleChangeCodigo: function handleChangeCodigo(codigo) {
      var _this2 = this;
      this.hadScann = false;
      setTimeout(function () {
        _this2.openScann = false;
      }, 3);
      this.codigo = codigo;
      this.addPersonal();
    },
    init: function init() {
      var _this3 = this;
      this.loading();
      _apis_usePeticiones__WEBPACK_IMPORTED_MODULE_2__["default"].getUltimaGuardiaHoras({
        usuario_id: this.userData.id
      }).then(function (response) {
        _this3.loading(false);
        var data = response.data.data;
        _this3.guardia = data.length != 1 ? null : data[0];
        _this3.voluntarios = _this3.guardia.voluntarios;
      })["catch"](function (error) {
        _this3.loading(false);
        console.log(error);
      });
    },
    handleOpenGuardia: function handleOpenGuardia() {
      var payload = {
        payload: {
          usuario_id: this.userData.id,
          accion: 1
        }
      };
      this.peticion(payload);
    },
    handleCerrarGuardia: function handleCerrarGuardia() {
      var payload = {
        payload: {
          guardia_id: this.guardia.id,
          accion: 7
        }
      };
      this.peticion(payload);
    },
    addPersonal: function addPersonal() {
      var payload = {
        payload: {
          usuario_id: this.userData.id,
          guardia_id: this.guardia.id,
          codigo: this.codigo,
          accion: 5
        }
      };
      this.peticion(payload);
    },
    handleClosePersonal: function handleClosePersonal(data) {
      console.log(data);
      var payload = {
        payload: {
          registroGuardiaVoluntario: data.id,
          accion: 6
        }
      };
      this.peticion(payload);
    },
    peticion: function peticion(payload) {
      var _this4 = this;
      this.loading();
      _apis_usePeticiones__WEBPACK_IMPORTED_MODULE_2__["default"].administrarGuardiaHoras(payload).then(function (response) {
        _this4.loading(false);
        console.log(payload);
        if (payload.payload.accion == 1) {
          var data = response.data.data;
          // console.log('data',data)
          // this.guardia = data.guardia;
          // this.voluntarios = data.guardia.voluntarios;
          _this4.init();
        }
        if (payload.payload.accion == 5) {
          _this4.messageConfirm({
            message: response.data.message,
            title: 'Información del sistema',
            icon: response.data.result ? 'success' : 'error',
            showCancelButton: false,
            confirmButtonText: 'Okay',
            cancelButtonText: 'No, cancelar',
            cancelFunction: null,
            messageCancel: false,
            confirmFunction: function confirmFunction() {
              _this4.init();
            }
          });
          _this4.init();
        }
        if (payload.payload.accion > 5) {
          _this4.messageConfirm({
            message: response.data.message,
            title: 'Información del sistema',
            icon: response.data.result ? 'success' : 'error',
            showCancelButton: false,
            confirmButtonText: 'Okay',
            cancelButtonText: 'No, cancelar',
            cancelFunction: null,
            messageCancel: false,
            confirmFunction: function confirmFunction() {
              _this4.init();
            }
          });
          _this4.init();
        }
      })["catch"](function (error) {
        _this4.loading(false);
        console.log(error);
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/voluntarios/formVoluntario.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/voluntarios/formVoluntario.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Users_plomo_Documents_MAMP_vol_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var vue_barcode_reader__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-barcode-reader */ "./node_modules/vue-barcode-reader/src/index.js");
/* harmony import */ var _currentComponents_FormFactory_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @currentComponents/FormFactory.vue */ "./resources/js/src/views/currentComponents/FormFactory.vue");
/* harmony import */ var _apis_usePeticiones__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/apis/usePeticiones */ "./resources/js/src/apis/usePeticiones.js");
/* harmony import */ var _helpers_customHelpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @helpers/customHelpers */ "./resources/js/src/helpers/customHelpers.js");
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/store */ "./resources/js/src/store/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//







/* harmony default export */ __webpack_exports__["default"] = ({
  name: "FormVoluntario",
  mixins: [_helpers_customHelpers__WEBPACK_IMPORTED_MODULE_4__["default"]],
  components: {
    StreamBarcodeReader: vue_barcode_reader__WEBPACK_IMPORTED_MODULE_1__["StreamBarcodeReader"],
    FormFactory: _currentComponents_FormFactory_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    BCard: bootstrap_vue__WEBPACK_IMPORTED_MODULE_6__["BCard"],
    BCardTitle: bootstrap_vue__WEBPACK_IMPORTED_MODULE_6__["BCardTitle"],
    BCardSubTitle: bootstrap_vue__WEBPACK_IMPORTED_MODULE_6__["BCardSubTitle"],
    BCardBody: bootstrap_vue__WEBPACK_IMPORTED_MODULE_6__["BCardBody"],
    BModal: bootstrap_vue__WEBPACK_IMPORTED_MODULE_6__["BModal"],
    BButton: bootstrap_vue__WEBPACK_IMPORTED_MODULE_6__["BButton"]
  },
  mounted: function mounted() {},
  data: function data() {
    return {
      userData: _store__WEBPACK_IMPORTED_MODULE_5__["default"].state.app.userData,
      formSchemaFormVoluntario: [{
        classContainer: 'col-4',
        type: 'input-asociado',
        name: 'numeroAsociado',
        value: 'numeroAsociado',
        label: 'Numero de asociado',
        placeholder: 'Introduce un numero de asociado'
      }, {
        classContainer: 'col-8',
        type: 'input-blank'
      }, {
        classContainer: 'col-12 col-md-4',
        type: 'input-text',
        name: 'nombre',
        value: 'nombre',
        label: 'Nombre',
        rules: 'required'
      }, {
        classContainer: 'col-12 col-md-4',
        type: 'input-text',
        name: 'primerApellido',
        value: 'primerApellido',
        label: 'Primer apellido:',
        rules: 'required'
      }, {
        classContainer: 'col-12 col-md-4',
        type: 'input-text',
        name: 'segundoApellido',
        value: 'segundoApellido',
        label: 'Segundo apellido:',
        rules: 'required'
      }, {
        classContainer: 'col-lg-6 col-md-6 col-12',
        type: 'email',
        name: 'correo',
        value: 'correo',
        prefixIcon: 'MailIcon',
        rules: 'required|email',
        label: 'Correo electronico',
        placeholder: 'Introduce un correo electronico'
      }, {
        classContainer: 'col-lg-6 col-md-6 col-12',
        type: 'input-text',
        name: 'curp',
        value: 'curp',
        label: 'CURP',
        rules: 'required'
      }]
    };
  },
  props: {
    data: {
      type: Object,
      "default": {}
    },
    withCard: {
      type: Boolean,
      "default": false
    },
    btnRegistrarHoras: {
      type: Boolean,
      "default": false
    },
    exportActions: {
      type: Boolean,
      "default": false
    },
    btnCancel: {
      type: Boolean,
      "default": true
    }
  },
  watch: {},
  computed: {},
  created: function created() {},
  beforeMount: function beforeMount() {
    console.log('formVoluntario');
  },
  methods: {
    handleCancel: function handleCancel() {
      this.$emit('handleCancelar');
    },
    handleSubmitFormVoluntario: function handleSubmitFormVoluntario(info) {
      if (this.exportActions) {
        this.$emit('handleSubmit', info);
      } else {
        var _this$userData$id;
        var payload = Object(_Users_plomo_Documents_MAMP_vol_node_modules_babel_runtime_helpers_esm_objectSpread2_js__WEBPACK_IMPORTED_MODULE_0__["default"])({}, info);
        payload.accion = 1;
        payload.userID = (_this$userData$id = this.userData.id) !== null && _this$userData$id !== void 0 ? _this$userData$id : null;
        this.peticionAdministrar(payload);
      }
    },
    onSubmitFormVoluntario: function onSubmitFormVoluntario() {
      this.$refs.formVoluntario.validationForm();
    },
    peticionAdministrar: function peticionAdministrar(payload) {
      var _this = this;
      this.loading();
      _apis_usePeticiones__WEBPACK_IMPORTED_MODULE_3__["default"].administrarVoluntarios({
        'payload': payload
      }).then(function (response) {
        _this.loading(false);
        _this.messageSweet({
          message: response.data.message,
          icon: response.data.result ? 'success' : 'error'
        });
        if (response.data.result) {
          _this.handleCancel();
        }
      })["catch"](function (error) {
        _this.loading(false);
        console.log(error);
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/laravel-mix/node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/currentComponents/ScannerCode.vue?vue&type=template&id=d734279e&scoped=true&":
/*!********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/laravel-mix/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/currentComponents/ScannerCode.vue?vue&type=template&id=d734279e&scoped=true& ***!
  \********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    _vm.isModal ? "b-modal" : "b-card",
    {
      ref: "my-modal",
      tag: "component",
      attrs: {
        "hide-footer": "",
        "ok-only": "",
        "no-close-on-backdrop": "",
        title: "Modal escaner",
      },
    },
    [
      _vm.loading
        ? _c(
            "h3",
            {
              staticClass:
                "col-12 m-0 p-0 font-weight-bolder text-primary text-center",
            },
            [_vm._v("Cargando camara!!....")]
          )
        : _vm._e(),
      _vm._v(" "),
      _c("StreamBarcodeReader", {
        ref: "scann",
        on: {
          decode: function (a, b, c) {
            return _vm.onDecode(a, b, c)
          },
          loaded: function () {
            return _vm.onLoaded()
          },
        },
      }),
      _vm._v("\n  Input Value: " + _vm._s(_vm.text || "Nothing") + "\n"),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/laravel-mix/node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/horas/Horas.vue?vue&type=template&id=368e1231&":
/*!**************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/laravel-mix/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/horas/Horas.vue?vue&type=template&id=368e1231& ***!
  \**************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    !_vm.showForm
      ? _c(
          "div",
          [
            _c("VistaUno", {
              attrs: { data: _vm.data, columnas: _vm.columnas },
              on: {
                mdoEditar: _vm.editar,
                mdoEliminar: _vm.onEliminar,
                mtdNuevo: _vm.nuevoRegistro,
                mtdFiltrar: _vm.reload,
              },
            }),
          ],
          1
        )
      : _vm._e(),
    _vm._v(" "),
    _vm.showForm
      ? _c(
          "div",
          [
            _vm.accion == 1
              ? _c("formHoras", {
                  attrs: { withCard: "", data: {} },
                  on: { handleSubmit: _vm.save, handleCancelar: _vm.resetForm },
                })
              : _vm._e(),
          ],
          1
        )
      : _vm._e(),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/laravel-mix/node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/horas/formHoras.vue?vue&type=template&id=2a8383ed&":
/*!******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/laravel-mix/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/horas/formHoras.vue?vue&type=template&id=2a8383ed& ***!
  \******************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _vm.tipoRegistro == null
      ? _c(
          "div",
          {
            staticClass:
              " col-10 mx-auto d-flex  flex-wrap justify-content-between",
          },
          [
            _c(
              "b-button",
              {
                attrs: { size: "sm", variant: "relief-secondary" },
                on: {
                  click: function () {
                    _vm.tipoRegistro = "porGaurdia"
                  },
                },
              },
              [_vm._v("Por Guardia")]
            ),
            _vm._v(" "),
            _c(
              "b-button",
              {
                attrs: { size: "sm", variant: "relief-secondary" },
                on: {
                  click: function () {
                    _vm.tipoRegistro = "porEvento"
                  },
                },
              },
              [_vm._v("Por evento")]
            ),
            _vm._v(" "),
            _c(
              "b-button",
              {
                attrs: { size: "sm", variant: "relief-secondary" },
                on: {
                  click: function () {
                    _vm.tipoRegistro = "porHora"
                  },
                },
              },
              [_vm._v("Por Hora")]
            ),
          ],
          1
        )
      : _vm._e(),
    _vm._v(" "),
    _vm.tipoRegistro == "porGaurdia"
      ? _c("div", [_c("FormPorGuardia")], 1)
      : _vm._e(),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/laravel-mix/node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/horas/formPorGuardia.vue?vue&type=template&id=59fe672a&":
/*!***********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/laravel-mix/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/horas/formPorGuardia.vue?vue&type=template&id=59fe672a& ***!
  \***********************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _vm.guardia == null
      ? _c(
          "div",
          { staticClass: " " },
          [
            _c(
              "h3",
              { staticClass: " font-weight-bolder class-12 text-center" },
              [_vm._v("No hay un turno abierto.")]
            ),
            _vm._v(" "),
            _c(
              "b-button",
              {
                staticClass: "mx-auto",
                attrs: { size: "sm", variant: "relief-secondary" },
                on: { click: _vm.handleOpenGuardia },
              },
              [_vm._v("Abrir guardia")]
            ),
          ],
          1
        )
      : _c(
          "div",
          { staticClass: "col-12 p-0 m-0" },
          [
            _c(
              "b-card",
              { staticClass: "col-6 mx-auto p-1 mb-2" },
              [
                _vm.hadScann
                  ? _c("Scann", {
                      attrs: { openScann: _vm.openScann, isModal: true },
                      on: { changeText: _vm.handleChangeCodigo },
                    })
                  : _vm._e(),
                _vm._v(" "),
                _c("div", { staticClass: "col-12 p-0 m-0 mb-2" }, [
                  _c(
                    "div",
                    { staticClass: "col-12 p-0 m-0 d-flex flex-wrap" },
                    [
                      _c(
                        "label",
                        {
                          staticClass:
                            "text-right mr-1 font-weight-bolder ww-100",
                        },
                        [_vm._v("Inicio:")]
                      ),
                      _vm._v(
                        _vm._s(_vm.formatoFechaYMD(_vm.guardia.inicio, true))
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "col-12 p-0 m-0 d-flex flex-wrap" },
                    [
                      _c(
                        "label",
                        {
                          staticClass:
                            "text-right mr-1 font-weight-bolder ww-100",
                        },
                        [_vm._v("Delegación:")]
                      ),
                      _vm._v(_vm._s(_vm.guardia.delegacion.nombre)),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "col-12 p-0 m-0 d-flex flex-wrap" },
                    [
                      _c(
                        "label",
                        {
                          staticClass:
                            "text-right mr-1 font-weight-bolder ww-100",
                        },
                        [_vm._v("Verificador:")]
                      ),
                      _vm._v(
                        _vm._s(
                          _vm.guardia.verificador.nombre +
                            " " +
                            _vm.guardia.verificador.primerApellido +
                            " " +
                            _vm.guardia.verificador.segundoApellido
                        )
                      ),
                    ]
                  ),
                ]),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "d-flex w-100 justify-content-between" },
                  [
                    _c(
                      "b-button",
                      {
                        attrs: { size: "sm", variant: "relief-secondary" },
                        on: { click: _vm.handleOpenScann },
                      },
                      [_vm._v("Agregar personal")]
                    ),
                    _vm._v(" "),
                    _c(
                      "b-button",
                      {
                        attrs: { size: "sm", variant: "relief-danger" },
                        on: { click: _vm.handleCerrarGuardia },
                      },
                      [_vm._v("Cerrar guardia")]
                    ),
                  ],
                  1
                ),
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "col-12 mx-auto m-0 p-0 d-flex flex-wrap" },
              [
                _c("h4", { staticClass: "col-12 mb-1 font-weight-bolder " }, [
                  _vm._v("Voluntarios registrados:"),
                ]),
                _vm._v(" "),
                _vm._l(_vm.voluntarios, function (item, index) {
                  return _c(
                    "div",
                    { staticClass: "ww-300 p-2" },
                    [
                      _c("b-card", { staticClass: " p-1" }, [
                        _c("div", {}, [
                          _c(
                            "p",
                            { staticClass: " m-0 p-0 font-weight-bolder " },
                            [_vm._v(_vm._s(item.voluntario.numeroAsociado))]
                          ),
                          _vm._v(" "),
                          _c(
                            "p",
                            { staticClass: " m-0 p-0 font-weight-bolder " },
                            [_vm._v(_vm._s(item.voluntario.nombre))]
                          ),
                          _vm._v(" "),
                          _c("small", [
                            _c(
                              "p",
                              {
                                staticClass:
                                  " m-0 p-0 text-sm font-weight-bolder ",
                              },
                              [_vm._v("Hora de entrada:")]
                            ),
                          ]),
                          _vm._v(" "),
                          _c("small", [
                            _c("p", { staticClass: " m-0 p-0 text-sm" }, [
                              _vm._v(
                                _vm._s(
                                  _vm.formatoFechaYMD(item.fechaInicio, true)
                                )
                              ),
                            ]),
                          ]),
                          _vm._v(" "),
                          _c("small", [
                            _c(
                              "p",
                              {
                                staticClass:
                                  " m-0 p-0 text-sm font-weight-bolder ",
                              },
                              [_vm._v("Hora de salida:")]
                            ),
                          ]),
                          _vm._v(" "),
                          _c("small", [
                            _c("p", { staticClass: " m-0 p-0 text-sm" }, [
                              _vm._v(
                                _vm._s(_vm.formatoFechaYMD(item.fechaFin, true))
                              ),
                            ]),
                          ]),
                        ]),
                        _vm._v(" "),
                        item.fechaFin == null
                          ? _c(
                              "div",
                              { staticClass: "col-12 p-0 m-0 mt-1" },
                              [
                                _c(
                                  "b-button",
                                  {
                                    staticClass: "mx-auto",
                                    attrs: {
                                      size: "sm",
                                      block: "",
                                      variant: "relief-danger",
                                    },
                                    on: {
                                      click: function ($event) {
                                        return _vm.handleClosePersonal(item)
                                      },
                                    },
                                  },
                                  [_vm._v("Checar salida")]
                                ),
                              ],
                              1
                            )
                          : _vm._e(),
                      ]),
                    ],
                    1
                  )
                }),
              ],
              2
            ),
          ],
          1
        ),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/laravel-mix/node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/voluntarios/formVoluntario.vue?vue&type=template&id=2a3b0348&":
/*!*****************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/laravel-mix/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/voluntarios/formVoluntario.vue?vue&type=template&id=2a3b0348& ***!
  \*****************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        _vm.withCard ? "b-card" : "div",
        { tag: "component", staticClass: "col-12 p-2" },
        [
          _c("FormFactory", {
            ref: "formVoluntario",
            staticClass: "col-12 mx-auto",
            attrs: {
              btnsAccion: false,
              data: _vm.data,
              schema: _vm.formSchemaFormVoluntario,
            },
            on: { formExport: _vm.handleSubmitFormVoluntario },
          }),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: " col-12 d-flex flex-wrap justify-content-between" },
            [
              _c(
                "div",
                [
                  _vm.btnCancel
                    ? _c(
                        "b-button",
                        {
                          attrs: { size: "sm", variant: "outline-danger" },
                          on: { click: _vm.handleCancel },
                        },
                        [_vm._v("Cancelar")]
                      )
                    : _vm._e(),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "div",
                [
                  typeof _vm.data.id != "undefined" && _vm.btnRegistrarHoras
                    ? _c(
                        "b-button",
                        {
                          attrs: { size: "sm", variant: "relief-secondary" },
                          on: {
                            click: function () {
                              _vm.$emit("handleShowFormHoras")
                            },
                          },
                        },
                        [_vm._v("Registrar horas voluntarias")]
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _c(
                    "b-button",
                    {
                      attrs: { size: "sm", variant: "relief-primary" },
                      on: { click: _vm.onSubmitFormVoluntario },
                    },
                    [_vm._v("Guardar")]
                  ),
                ],
                1
              ),
            ]
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/currentComponents/ScannerCode.vue":
/*!******************************************************************!*\
  !*** ./resources/js/src/views/currentComponents/ScannerCode.vue ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ScannerCode_vue_vue_type_template_id_d734279e_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ScannerCode.vue?vue&type=template&id=d734279e&scoped=true& */ "./resources/js/src/views/currentComponents/ScannerCode.vue?vue&type=template&id=d734279e&scoped=true&");
/* harmony import */ var _ScannerCode_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ScannerCode.vue?vue&type=script&lang=js& */ "./resources/js/src/views/currentComponents/ScannerCode.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ScannerCode_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ScannerCode_vue_vue_type_template_id_d734279e_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ScannerCode_vue_vue_type_template_id_d734279e_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "d734279e",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/currentComponents/ScannerCode.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/currentComponents/ScannerCode.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************!*\
  !*** ./resources/js/src/views/currentComponents/ScannerCode.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ScannerCode_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./ScannerCode.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/currentComponents/ScannerCode.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ScannerCode_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/currentComponents/ScannerCode.vue?vue&type=template&id=d734279e&scoped=true&":
/*!*************************************************************************************************************!*\
  !*** ./resources/js/src/views/currentComponents/ScannerCode.vue?vue&type=template&id=d734279e&scoped=true& ***!
  \*************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_laravel_mix_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ScannerCode_vue_vue_type_template_id_d734279e_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/laravel-mix/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./ScannerCode.vue?vue&type=template&id=d734279e&scoped=true& */ "./node_modules/laravel-mix/node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/currentComponents/ScannerCode.vue?vue&type=template&id=d734279e&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_laravel_mix_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ScannerCode_vue_vue_type_template_id_d734279e_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_laravel_mix_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ScannerCode_vue_vue_type_template_id_d734279e_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/horas/Horas.vue":
/*!************************************************!*\
  !*** ./resources/js/src/views/horas/Horas.vue ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Horas_vue_vue_type_template_id_368e1231___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Horas.vue?vue&type=template&id=368e1231& */ "./resources/js/src/views/horas/Horas.vue?vue&type=template&id=368e1231&");
/* harmony import */ var _Horas_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Horas.vue?vue&type=script&lang=js& */ "./resources/js/src/views/horas/Horas.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Horas_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Horas_vue_vue_type_template_id_368e1231___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Horas_vue_vue_type_template_id_368e1231___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/horas/Horas.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/horas/Horas.vue?vue&type=script&lang=js&":
/*!*************************************************************************!*\
  !*** ./resources/js/src/views/horas/Horas.vue?vue&type=script&lang=js& ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Horas_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Horas.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/horas/Horas.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Horas_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/horas/Horas.vue?vue&type=template&id=368e1231&":
/*!*******************************************************************************!*\
  !*** ./resources/js/src/views/horas/Horas.vue?vue&type=template&id=368e1231& ***!
  \*******************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_laravel_mix_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Horas_vue_vue_type_template_id_368e1231___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/laravel-mix/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Horas.vue?vue&type=template&id=368e1231& */ "./node_modules/laravel-mix/node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/horas/Horas.vue?vue&type=template&id=368e1231&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_laravel_mix_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Horas_vue_vue_type_template_id_368e1231___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_laravel_mix_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Horas_vue_vue_type_template_id_368e1231___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/horas/formHoras.vue":
/*!****************************************************!*\
  !*** ./resources/js/src/views/horas/formHoras.vue ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _formHoras_vue_vue_type_template_id_2a8383ed___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./formHoras.vue?vue&type=template&id=2a8383ed& */ "./resources/js/src/views/horas/formHoras.vue?vue&type=template&id=2a8383ed&");
/* harmony import */ var _formHoras_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./formHoras.vue?vue&type=script&lang=js& */ "./resources/js/src/views/horas/formHoras.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _formHoras_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _formHoras_vue_vue_type_template_id_2a8383ed___WEBPACK_IMPORTED_MODULE_0__["render"],
  _formHoras_vue_vue_type_template_id_2a8383ed___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/horas/formHoras.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/horas/formHoras.vue?vue&type=script&lang=js&":
/*!*****************************************************************************!*\
  !*** ./resources/js/src/views/horas/formHoras.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_formHoras_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./formHoras.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/horas/formHoras.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_formHoras_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/horas/formHoras.vue?vue&type=template&id=2a8383ed&":
/*!***********************************************************************************!*\
  !*** ./resources/js/src/views/horas/formHoras.vue?vue&type=template&id=2a8383ed& ***!
  \***********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_laravel_mix_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_formHoras_vue_vue_type_template_id_2a8383ed___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/laravel-mix/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./formHoras.vue?vue&type=template&id=2a8383ed& */ "./node_modules/laravel-mix/node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/horas/formHoras.vue?vue&type=template&id=2a8383ed&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_laravel_mix_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_formHoras_vue_vue_type_template_id_2a8383ed___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_laravel_mix_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_formHoras_vue_vue_type_template_id_2a8383ed___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/horas/formPorGuardia.vue":
/*!*********************************************************!*\
  !*** ./resources/js/src/views/horas/formPorGuardia.vue ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _formPorGuardia_vue_vue_type_template_id_59fe672a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./formPorGuardia.vue?vue&type=template&id=59fe672a& */ "./resources/js/src/views/horas/formPorGuardia.vue?vue&type=template&id=59fe672a&");
/* harmony import */ var _formPorGuardia_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./formPorGuardia.vue?vue&type=script&lang=js& */ "./resources/js/src/views/horas/formPorGuardia.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _formPorGuardia_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _formPorGuardia_vue_vue_type_template_id_59fe672a___WEBPACK_IMPORTED_MODULE_0__["render"],
  _formPorGuardia_vue_vue_type_template_id_59fe672a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/horas/formPorGuardia.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/horas/formPorGuardia.vue?vue&type=script&lang=js&":
/*!**********************************************************************************!*\
  !*** ./resources/js/src/views/horas/formPorGuardia.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_formPorGuardia_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./formPorGuardia.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/horas/formPorGuardia.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_formPorGuardia_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/horas/formPorGuardia.vue?vue&type=template&id=59fe672a&":
/*!****************************************************************************************!*\
  !*** ./resources/js/src/views/horas/formPorGuardia.vue?vue&type=template&id=59fe672a& ***!
  \****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_laravel_mix_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_formPorGuardia_vue_vue_type_template_id_59fe672a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/laravel-mix/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./formPorGuardia.vue?vue&type=template&id=59fe672a& */ "./node_modules/laravel-mix/node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/horas/formPorGuardia.vue?vue&type=template&id=59fe672a&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_laravel_mix_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_formPorGuardia_vue_vue_type_template_id_59fe672a___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_laravel_mix_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_formPorGuardia_vue_vue_type_template_id_59fe672a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/voluntarios/formVoluntario.vue":
/*!***************************************************************!*\
  !*** ./resources/js/src/views/voluntarios/formVoluntario.vue ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _formVoluntario_vue_vue_type_template_id_2a3b0348___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./formVoluntario.vue?vue&type=template&id=2a3b0348& */ "./resources/js/src/views/voluntarios/formVoluntario.vue?vue&type=template&id=2a3b0348&");
/* harmony import */ var _formVoluntario_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./formVoluntario.vue?vue&type=script&lang=js& */ "./resources/js/src/views/voluntarios/formVoluntario.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _formVoluntario_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _formVoluntario_vue_vue_type_template_id_2a3b0348___WEBPACK_IMPORTED_MODULE_0__["render"],
  _formVoluntario_vue_vue_type_template_id_2a3b0348___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/voluntarios/formVoluntario.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/voluntarios/formVoluntario.vue?vue&type=script&lang=js&":
/*!****************************************************************************************!*\
  !*** ./resources/js/src/views/voluntarios/formVoluntario.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_formVoluntario_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./formVoluntario.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/voluntarios/formVoluntario.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_formVoluntario_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/voluntarios/formVoluntario.vue?vue&type=template&id=2a3b0348&":
/*!**********************************************************************************************!*\
  !*** ./resources/js/src/views/voluntarios/formVoluntario.vue?vue&type=template&id=2a3b0348& ***!
  \**********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_laravel_mix_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_formVoluntario_vue_vue_type_template_id_2a3b0348___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/laravel-mix/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./formVoluntario.vue?vue&type=template&id=2a3b0348& */ "./node_modules/laravel-mix/node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/voluntarios/formVoluntario.vue?vue&type=template&id=2a3b0348&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_laravel_mix_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_formVoluntario_vue_vue_type_template_id_2a3b0348___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_laravel_mix_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_formVoluntario_vue_vue_type_template_id_2a3b0348___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);