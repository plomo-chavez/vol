<!DOCTYPE html>
<html>
<head>
    <title>{{ $data['title'] }}</title>
</head>
<body>
    {!! $data['html'] !!}
</body>
</html>
