export default [
  {
    title: 'Inicio',
    route: 'home',
    icon: 'HomeIcon',
  },
]
