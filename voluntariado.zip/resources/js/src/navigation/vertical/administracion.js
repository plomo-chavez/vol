export default [
  {
    title: 'Administración',
    icon: 'SettingsIcon',
    children: [
        {
          title: 'Usuarios',
          route: 'usuarios',
        },
        {
          title: 'Voluntarios',
          route: 'voluntarios',
        },
    ],
  },
]
