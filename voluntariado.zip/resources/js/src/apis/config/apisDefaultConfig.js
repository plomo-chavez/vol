export default {
  // Endpoints
  pruebasEndPoint: '/api/auth/pruebas',
  pruebas2EndPoint: '/api/auth/pruebas2',
  getUsuarios: '/api/get/usuarios',
}
