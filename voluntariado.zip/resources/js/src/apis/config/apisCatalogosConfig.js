export default {
  // Endpoints
  apiTiposUsuarios: '/api/catalogo/tiposUsuarios',
  estatusHabitacionesApi: '/api/catalogo/estatusHabitaciones',
  habitacionesApi: '/api/catalogo/habitaciones',
  customPersonsApi: '/api/catalogo/customPersons',
  roomsAvailableApi: '/api/catalogo/roomsAvailable',
}
